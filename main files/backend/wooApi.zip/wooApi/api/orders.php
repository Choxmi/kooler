<?php

/*
 * Following code will list all the products
 */

// array for JSON response
$response = array();


// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();

// get all products from products table
$result = mysql_query("SELECT * FROM orders") or die(mysql_error());


$json = array();
$total_records = mysql_num_rows($result);

if($total_records >= 1){
  while ($row = mysql_fetch_array($result, MYSQL_ASSOC)){

  	$order_number = $row['order_number'];
  	
  	$result2 = mysql_query("SELECT * FROM order_items WHERE order_id = '$order_number'") or die(mysql_error());
  	$json2 = array();
	$total_records2 = mysql_num_rows($result2);

	if($total_records2 >= 1){
	  while ($row2 = mysql_fetch_array($result2, MYSQL_ASSOC)){
	    $json2[] = $row2;
	  }
	}

  	$row['products'] = $json2;
    $json[] = $row;
  }
}

echo json_encode($json);

?>
