<?php

/*
 * All database connection variables
 */

define('DB_USER', "kimutai_woo"); // db user
define('DB_PASSWORD', "woo2014"); // db password (mention your db password here)
define('DB_DATABASE', "kimutai_woo"); // database name
define('DB_SERVER', "localhost"); // db server
?>